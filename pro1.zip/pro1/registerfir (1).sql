-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 27, 2020 at 04:46 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fir`
--

-- --------------------------------------------------------

--
-- Table structure for table `registerfir`
--

DROP TABLE IF EXISTS `registerfir`;
CREATE TABLE IF NOT EXISTS `registerfir` (
  `id` int(250) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(250) NOT NULL,
  `last_name` varchar(250) NOT NULL,
  `Date_of_complaint` date NOT NULL,
  `gender` varchar(250) NOT NULL,
  `father` varchar(250) NOT NULL,
  `address` varchar(500) NOT NULL,
  `email` varchar(250) NOT NULL,
  `phone` int(15) NOT NULL,
  `afirst_name` varchar(250) NOT NULL,
  `alast_name` varchar(250) NOT NULL,
  `aaddress` varchar(500) NOT NULL,
  `relation` varchar(250) NOT NULL,
  `police` varchar(250) NOT NULL,
  `subject` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registerfir`
--

INSERT INTO `registerfir` (`id`, `first_name`, `last_name`, `Date_of_complaint`, `gender`, `father`, `address`, `email`, `phone`, `afirst_name`, `alast_name`, `aaddress`, `relation`, `police`, `subject`) VALUES
(3, 'Mohan', 'Rao', '0000-00-00', 'on', 'M Achuta Rao', 'Pranveer Singh Institute of Technology, Bhauti', 'mohanrao.psit@gmail.com', 2147483647, 'Mohan', 'Rao', 'Pranveer Singh Institute of Technology', 'self', 'Mohan Rao', 'Accidental'),
(4, 'Mohan', 'Rao', '0000-00-00', 'on', 'M Achuta Rao', 'Pranveer Singh Institute of Technology, Bhauti', 'mohanrao.psit@gmail.com', 2147483647, 'Mohan', 'Rao', 'Pranveer Singh Institute of Technology', 'self', 'Mohan Rao', 'Accidental'),
(5, 'Mohan', 'Rao', '0000-00-00', 'on', 'M Achuta Rao', 'Pranveer Singh Institute of Technology, Bhauti', 'mohanrao.psit@gmail.com', 2147483647, 'Mohan', 'Rao', 'Pranveer Singh Institute of Technology', 'self', 'Mohan Rao', ''),
(6, 'Mohan', 'Rao', '0000-00-00', 'on', 'M Achuta Rao', 'Pranveer Singh Institute of Technology, Bhauti', 'mohanrao.psit@gmail.com', 2147483647, 'Mohan', 'Rao', 'Pranveer Singh Institute of Technology', 'self', 'Mohan Rao', 'Accidental'),
(7, 'Mohan', 'Rao', '0000-00-00', 'on', 'M Achuta Rao', 'Pranveer Singh Institute of Technology, Bhauti', 'mohanrao.psit@gmail.com', 2147483647, 'Mohan', 'Rao', 'Pranveer Singh Institute of Technology', 'self', 'Mohan Rao', 'Accidental'),
(8, 'Mohan', 'Rao', '0000-00-00', 'on', 'M Achuta Rao', 'Pranveer Singh Institute of Technology, Bhauti', 'mohanrao.psit@gmail.com', 2147483647, 'Mohan', 'Rao', 'Pranveer Singh Institute of Technology', 'self', 'Mohan Rao', 'Accidental'),
(9, 'Mohan', 'Rao', '0000-00-00', 'on', 'M Achuta Rao', 'Pranveer Singh Institute of Technology, Bhauti', 'mohanrao.psit@gmail.com', 2147483647, 'Mohan', 'Rao', 'Pranveer Singh Institute of Technology', 'self', 'Mohan Rao', 'Accidental'),
(10, 'Mohan', 'Rao', '0000-00-00', '0', 'M Achuta Rao', 'Pranveer Singh Institute of Technology, Bhauti', 'mohanrao.psit@gmail.com', 2147483647, 'Mohan', 'Rao', 'Pranveer Singh Institute of Technology', 'self', 'Mohan Rao', 'Accidental'),
(11, 'Mohan', 'Rao', '0000-00-00', 'Male', 'M Achuta Rao', 'Pranveer Singh Institute of Technology, Bhauti', 'mohanrao.psit@gmail.com', 2147483647, 'Mohan', 'Rao', 'Pranveer Singh Institute of Technology', 'self', 'Mohan Rao', 'Accidental');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
